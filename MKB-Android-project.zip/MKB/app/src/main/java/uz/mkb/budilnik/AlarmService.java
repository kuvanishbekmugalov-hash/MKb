package uz.mkb.budilnik;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.util.Calendar;
import java.util.Random;

/** Foreground-сервис: играет звук и вибрирует, пока будильник не остановят. */
public class AlarmService extends Service {
    static final String ACTION_START = "uz.mkb.budilnik.START";
    static final String ACTION_STOP = "uz.mkb.budilnik.STOP";
    static final String ACTION_SNOOZE = "uz.mkb.budilnik.SNOOZE";
    static final String CH_ALARM = "mkb_alarm";
    static final int NID = 7001;

    static volatile boolean ringing = false;
    static volatile String curTime = "";
    static volatile String curLabel = "";
    static volatile boolean curMath = false;
    static volatile int curSnooze = 5;
    static volatile int mathX = 0;
    static volatile int mathY = 0;

    private MediaPlayer mp;
    private Vibrator vib;
    private PowerManager.WakeLock wl;
    private ToneGenerator tone;
    private final Handler h = new Handler(Looper.getMainLooper());
    private long[] ids = new long[0];
    private float vol = 0.2f;

    private final Runnable ramp = new Runnable() {
        @Override
        public void run() {
            if (mp != null && vol < 1f) {
                vol = Math.min(1f, vol + 0.1f);
                try { mp.setVolume(vol, vol); } catch (Exception ignored) { }
                h.postDelayed(this, 3000);
            }
        }
    };

    private final Runnable toneLoop = new Runnable() {
        @Override
        public void run() {
            if (tone != null) {
                try { tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700); } catch (Exception ignored) { }
                h.postDelayed(this, 1000);
            }
        }
    };

    private final Runnable timeout = new Runnable() {
        @Override
        public void run() {
            Scheduler.notifyFallbackSilent(AlarmService.this, curLabel);
            finishRinging(false);
        }
    };

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(act)) { finishRinging(false); return START_NOT_STICKY; }
        if (ACTION_SNOOZE.equals(act)) { finishRinging(true); return START_NOT_STICKY; }

        long[] nids = intent == null ? null : intent.getLongArrayExtra("ids");
        boolean test = intent != null && intent.getBooleanExtra("test", false);

        StringBuilder label = new StringBuilder();
        boolean math = false;
        int snz = 5;
        String sndKey = null;
        String time = "";
        boolean any = false;
        if (test) {
            label.append("Проверка будильника");
        } else if (nids != null) {
            for (long id : nids) {
                JSONObject a = Scheduler.alarmById(this, id);
                if (a == null) continue;
                if (!any) { time = a.optString("time", ""); snz = a.optInt("snz", 5); }
                any = true;
                String l = a.optString("label", "");
                if (l.isEmpty()) l = "Будильник";
                if (label.length() > 0) label.append(" · ");
                label.append(l);
                if (a.optBoolean("math", false)) math = true;
                String s = a.optString("snd", "");
                if (sndKey == null && s.startsWith("native:")) sndKey = s.substring(7);
            }
        }
        if (label.length() == 0) label.append("Будильник");
        if (time.isEmpty()) {
            Calendar c = Calendar.getInstance();
            time = Scheduler.two(c.get(Calendar.HOUR_OF_DAY)) + ":" + Scheduler.two(c.get(Calendar.MINUTE));
        }

        if (ringing) {
            // второй будильник сработал, пока звонит первый
            if (nids != null) {
                long[] merged = new long[ids.length + nids.length];
                System.arraycopy(ids, 0, merged, 0, ids.length);
                System.arraycopy(nids, 0, merged, ids.length, nids.length);
                ids = merged;
            }
            curLabel = curLabel + " · " + label;
            if (math) curMath = true;
            startFg(buildNotification());
            return START_NOT_STICKY;
        }

        ids = nids == null ? new long[0] : nids;
        curLabel = label.toString();
        curTime = time;
        curMath = math;
        curSnooze = Math.max(1, snz);
        Random rnd = new Random();
        mathX = 10 + rnd.nextInt(40);
        mathY = 10 + rnd.nextInt(40);
        ringing = true;

        startFg(buildNotification());

        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mkb:alarm");
            wl.acquire(11 * 60 * 1000L);
        } catch (Exception ignored) { }

        startSound(sndKey);
        startVibration();
        h.postDelayed(ramp, 3000);
        h.postDelayed(timeout, 10 * 60 * 1000L);

        try {
            Intent ai = new Intent(this, AlarmActivity.class);
            ai.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            startActivity(ai);
        } catch (Exception ignored) { }
        return START_NOT_STICKY;
    }

    private void startFg(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NID, n);
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH_ALARM, "Будильник", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setShowBadge(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        Intent fi = new Intent(this, AlarmActivity.class);
        fi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fsPi = PendingIntent.getActivity(this, 1, fi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(this, CH_ALARM)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle("⏰ " + curLabel)
                .setContentText(curTime)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(fsPi)
                .setFullScreenIntent(fsPi, true);
        Intent sn = new Intent(this, AlarmService.class);
        sn.setAction(ACTION_SNOOZE);
        PendingIntent snPi = PendingIntent.getService(this, 2, sn, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.addAction(R.drawable.ic_stat_alarm, "Отложить " + curSnooze + " мин", snPi);
        if (!curMath) {
            Intent st = new Intent(this, AlarmService.class);
            st.setAction(ACTION_STOP);
            PendingIntent stPi = PendingIntent.getService(this, 3, st, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.addAction(R.drawable.ic_stat_alarm, "Выключить", stPi);
        }
        return b.build();
    }

    private boolean tryPlay(File f) {
        MediaPlayer m = null;
        try {
            m = new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            if (f != null) {
                FileInputStream fis = new FileInputStream(f);
                try { m.setDataSource(fis.getFD()); } finally { fis.close(); }
            } else {
                Uri u = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
                if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                m.setDataSource(this, u);
            }
            m.setLooping(true);
            m.setVolume(vol, vol);
            m.prepare();
            m.start();
            mp = m;
            return true;
        } catch (Exception e) {
            try { if (m != null) m.release(); } catch (Exception ignored) { }
            return false;
        }
    }

    private void startSound(String sndKey) {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) == 0) {
                int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
                am.setStreamVolume(AudioManager.STREAM_ALARM, Math.max(1, (int) (max * 0.6f)), 0);
            }
        } catch (Exception ignored) { }
        boolean ok = false;
        if (sndKey != null) {
            File f = Scheduler.soundFile(this, sndKey);
            if (f.exists() && f.length() > 0) ok = tryPlay(f);
        }
        if (!ok) ok = tryPlay(null);
        if (!ok) {
            try { tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100); } catch (Exception e) { tone = null; }
            if (tone != null) h.post(toneLoop);
        }
    }

    private void startVibration() {
        try {
            vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 600, 400, 600, 400, 600, 1500}, 0));
            }
        } catch (Exception ignored) { }
    }

    private void releaseAll() {
        h.removeCallbacksAndMessages(null);
        try { if (mp != null) { mp.stop(); } } catch (Exception ignored) { }
        try { if (mp != null) { mp.release(); } } catch (Exception ignored) { }
        mp = null;
        try { if (tone != null) tone.release(); } catch (Exception ignored) { }
        tone = null;
        try { if (vib != null) vib.cancel(); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        wl = null;
    }

    private void finishRinging(boolean snooze) {
        releaseAll();
        long[] done = ids;
        ringing = false;
        try {
            if (snooze && done.length > 0) Scheduler.snooze(this, done, curSnooze);
            else Scheduler.scheduleNext(this);
            Widgets.updateAll(this);
        } catch (Exception ignored) { }
        ids = new long[0];
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        AlarmActivity.finishCurrent();
        stopSelf();
    }

    @Override
    public void onDestroy() {
        releaseAll();
        ringing = false;
        super.onDestroy();
    }
}
