package uz.mkb.budilnik;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import java.util.List;

public class BirthdayWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { update(c, m, ids); }

    static void update(Context c, AppWidgetManager m, int[] ids) {
        List<Widgets.Bd> l = Widgets.upcoming(c);
        for (int id : ids) {
            try {
                RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_birthday);
                if (l.isEmpty()) {
                    rv.setTextViewText(R.id.bd_name, "Нет данных");
                    rv.setTextViewText(R.id.bd_when, "Добавьте день рождения");
                    rv.setTextViewText(R.id.bd_date, "События → Дни рождения → +");
                    rv.setTextViewText(R.id.bd_more, "");
                } else {
                    Widgets.Bd b = l.get(0);
                    rv.setTextViewText(R.id.bd_name, b.name);
                    rv.setTextViewText(R.id.bd_when, Widgets.whenText(b.days));
                    String d = b.day + " " + Widgets.GEN[b.month - 1];
                    if (b.age > 0) d += " · исполнится " + b.age;
                    rv.setTextViewText(R.id.bd_date, d);
                    StringBuilder more = new StringBuilder();
                    for (int i = 1; i < l.size() && i <= 2; i++) {
                        Widgets.Bd x = l.get(i);
                        if (more.length() > 0) more.append("\n");
                        more.append("• ").append(x.name).append(" — ").append(Widgets.whenText(x.days));
                    }
                    rv.setTextViewText(R.id.bd_more, more.toString());
                }
                rv.setOnClickPendingIntent(R.id.root, Widgets.openTab(c, "bd", 2));
                m.updateAppWidget(id, rv);
            } catch (Exception ignored) { }
        }
    }
}
