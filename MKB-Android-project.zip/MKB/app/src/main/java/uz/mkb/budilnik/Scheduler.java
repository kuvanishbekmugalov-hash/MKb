package uz.mkb.budilnik;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/** Вся логика расписания: будильники (setAlarmClock) и напоминания о днях рождения. */
final class Scheduler {
    static final String ACTION_ALARM = "uz.mkb.budilnik.ALARM";
    static final String ACTION_BDAY = "uz.mkb.budilnik.BDAY";
    static final String ACTION_TICK = "uz.mkb.budilnik.TICK";
    static final String CH_INFO = "mkb_info";
    static final String CH_FALLBACK = "mkb_fallback";

    static final class Next {
        long t;
        String label = "";
        String time = "";
    }

    private Scheduler() {}

    // ---------- хранилище ----------
    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("mkb", Context.MODE_PRIVATE);
    }

    static JSONArray arr(Context c, String key) {
        try { return new JSONArray(sp(c).getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    static JSONObject obj(Context c, String key) {
        try { return new JSONObject(sp(c).getString(key, "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static void putQ(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception ignored) { }
    }

    static String two(int n) { return n < 10 ? "0" + n : String.valueOf(n); }

    static String dateKey(Calendar c) {
        return c.get(Calendar.YEAR) + "-" + two(c.get(Calendar.MONTH) + 1) + "-" + two(c.get(Calendar.DAY_OF_MONTH));
    }

    /** Пн=0 ... Вс=6, как в JS-приложении. */
    static int dow(Calendar c) { return (c.get(Calendar.DAY_OF_WEEK) + 5) % 7; }

    static File soundFile(Context c, String key) {
        return new File(c.getApplicationContext().getFilesDir(), "snd_" + key.replaceAll("[^A-Za-z0-9_-]", ""));
    }

    static JSONObject alarmById(Context c, long id) {
        JSONArray al = arr(c, "alarms");
        for (int i = 0; i < al.length(); i++) {
            JSONObject a = al.optJSONObject(i);
            if (a != null && a.optLong("id") == id) return a;
        }
        return null;
    }

    // ---------- будильники ----------
    static boolean matches(JSONObject a, Calendar day) {
        JSONArray days = a.optJSONArray("days");
        if (days != null) {
            int d = dow(day);
            for (int i = 0; i < days.length(); i++) if (days.optInt(i, -1) == d) return true;
        }
        JSONArray dates = a.optJSONArray("dates");
        if (dates != null) {
            String k = dateKey(day);
            for (int i = 0; i < dates.length(); i++) if (k.equals(dates.optString(i))) return true;
        }
        return false;
    }

    static long slot(JSONObject a, Calendar day) {
        String t = a.optString("time", "07:00");
        int h = 7, m = 0;
        try {
            h = Integer.parseInt(t.substring(0, 2));
            m = Integer.parseInt(t.substring(3, 5));
        } catch (Exception ignored) { }
        Calendar c = (Calendar) day.clone();
        c.set(Calendar.HOUR_OF_DAY, h);
        c.set(Calendar.MINUTE, m);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    static Next nextAlarm(Context c, long now) {
        JSONArray al = arr(c, "alarms");
        JSONObject fired = obj(c, "fired");
        JSONObject snz = obj(c, "snooze");
        Next best = null;
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(now);
        for (int i = 0; i < 400; i++) {
            for (int j = 0; j < al.length(); j++) {
                JSONObject a = al.optJSONObject(j);
                if (a == null || !a.optBoolean("on", false)) continue;
                if (!matches(a, day)) continue;
                long t = slot(a, day);
                if (t <= now) continue;
                String key = dateKey(day) + " " + a.optString("time");
                if (key.equals(fired.optString(String.valueOf(a.optLong("id")), ""))) continue;
                if (best == null || t < best.t) {
                    best = new Next();
                    best.t = t;
                    best.label = a.optString("label", "");
                    best.time = a.optString("time", "");
                }
            }
            day.add(Calendar.DAY_OF_MONTH, 1);
        }
        Iterator<String> it = snz.keys();
        while (it.hasNext()) {
            String k = it.next();
            long t = snz.optLong(k, 0);
            if (t <= now) continue;
            JSONObject a = null;
            try { a = alarmById(c, Long.parseLong(k)); } catch (Exception ignored) { }
            if (a == null || !a.optBoolean("on", false)) continue;
            if (best == null || t < best.t) {
                Calendar tc = Calendar.getInstance();
                tc.setTimeInMillis(t);
                best = new Next();
                best.t = t;
                best.label = a.optString("label", "");
                best.time = two(tc.get(Calendar.HOUR_OF_DAY)) + ":" + two(tc.get(Calendar.MINUTE));
            }
        }
        return best;
    }

    static void scheduleNext(Context c) {
        Context ctx = c.getApplicationContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent oi = new Intent(ctx, AlarmReceiver.class);
        oi.setAction(ACTION_ALARM);
        PendingIntent op = PendingIntent.getBroadcast(ctx, 100, oi,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Next n = nextAlarm(ctx, System.currentTimeMillis());
        if (n == null) {
            am.cancel(op);
            return;
        }
        Intent si = new Intent(ctx, MainActivity.class);
        si.putExtra("tab", "al");
        si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent show = PendingIntent.getActivity(ctx, 101, si,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(n.t, show), op);
        } catch (Exception e) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.t, op);
            } catch (Exception e2) {
                am.set(AlarmManager.RTC_WAKEUP, n.t, op);
            }
        }
    }

    /** Вызывается по срабатыванию системного будильника. */
    static void fire(Context c) {
        Context ctx = c.getApplicationContext();
        long now = System.currentTimeMillis();
        JSONArray al = arr(ctx, "alarms");
        JSONObject fired = obj(ctx, "fired");
        JSONObject snz = obj(ctx, "snooze");
        Calendar day = Calendar.getInstance();
        day.setTimeInMillis(now);
        List<Long> ids = new ArrayList<>();
        for (int i = 0; i < al.length(); i++) {
            JSONObject a = al.optJSONObject(i);
            if (a == null || !a.optBoolean("on", false)) continue;
            long id = a.optLong("id");
            String sid = String.valueOf(id);
            boolean added = false;
            if (matches(a, day)) {
                long t = slot(a, day);
                String key = dateKey(day) + " " + a.optString("time");
                if (t <= now + 3000 && t > now - 180000 && !key.equals(fired.optString(sid, ""))) {
                    putQ(fired, sid, key);
                    ids.add(id);
                    added = true;
                }
            }
            long sn = snz.optLong(sid, 0);
            if (sn > 0 && sn <= now + 3000) {
                snz.remove(sid);
                if (!added && sn > now - 900000) ids.add(id);
            }
        }
        sp(ctx).edit().putString("fired", fired.toString()).putString("snooze", snz.toString()).apply();
        scheduleNext(ctx);
        Widgets.updateAll(ctx);
        if (ids.isEmpty()) return;
        long[] arrIds = new long[ids.size()];
        for (int i = 0; i < arrIds.length; i++) arrIds[i] = ids.get(i);
        Intent si = new Intent(ctx, AlarmService.class);
        si.setAction(AlarmService.ACTION_START);
        si.putExtra("ids", arrIds);
        try {
            ctx.startForegroundService(si);
        } catch (Exception e) {
            notifyFallback(ctx, ids.size() > 0 ? alarmLabel(ctx, ids.get(0)) : "Будильник");
        }
    }

    static String alarmLabel(Context c, long id) {
        JSONObject a = alarmById(c, id);
        String l = a == null ? "" : a.optString("label", "");
        return l.isEmpty() ? "Будильник" : l;
    }

    static void ringTest(Context c) {
        Context ctx = c.getApplicationContext();
        Intent si = new Intent(ctx, AlarmService.class);
        si.setAction(AlarmService.ACTION_START);
        si.putExtra("test", true);
        try { ctx.startForegroundService(si); } catch (Exception ignored) { }
    }

    static void snooze(Context c, long[] ids, int minutes) {
        JSONObject snz = obj(c, "snooze");
        long t = System.currentTimeMillis() + minutes * 60000L;
        for (long id : ids) putQ(snz, String.valueOf(id), t);
        sp(c).edit().putString("snooze", snz.toString()).apply();
        scheduleNext(c);
    }

    static void onAlarmsSynced(Context c, String json) {
        Context ctx = c.getApplicationContext();
        JSONArray al;
        try { al = new JSONArray(json); } catch (Exception e) { return; }
        sp(ctx).edit().putString("alarms", al.toString()).apply();
        Set<String> ids = new HashSet<>();
        Set<String> keep = new HashSet<>();
        for (int i = 0; i < al.length(); i++) {
            JSONObject a = al.optJSONObject(i);
            if (a == null) continue;
            ids.add(String.valueOf(a.optLong("id")));
            String s = a.optString("snd", "");
            if (s.startsWith("native:")) keep.add(s.substring(7).replaceAll("[^A-Za-z0-9_-]", ""));
        }
        JSONObject fired = obj(ctx, "fired");
        JSONObject snz = obj(ctx, "snooze");
        List<String> rm = new ArrayList<>();
        Iterator<String> it = fired.keys();
        while (it.hasNext()) { String k = it.next(); if (!ids.contains(k)) rm.add(k); }
        for (String k : rm) fired.remove(k);
        rm.clear();
        it = snz.keys();
        while (it.hasNext()) { String k = it.next(); if (!ids.contains(k)) rm.add(k); }
        for (String k : rm) snz.remove(k);
        sp(ctx).edit().putString("fired", fired.toString()).putString("snooze", snz.toString()).apply();
        try {
            File[] fs = ctx.getFilesDir().listFiles();
            if (fs != null) for (File f : fs) {
                String n = f.getName();
                if (n.startsWith("snd_") && !keep.contains(n.substring(4))) f.delete();
            }
        } catch (Exception ignored) { }
        scheduleNext(ctx);
        Widgets.updateAll(ctx);
    }

    // ---------- дни рождения ----------
    static void onBirthdaysSynced(Context c, String json) {
        Context ctx = c.getApplicationContext();
        try { new JSONArray(json); } catch (Exception e) { return; }
        sp(ctx).edit().putString("bdall", json).apply();
        fireBirthdays(ctx);
        Widgets.updateAll(ctx);
    }

    static void ensureChannels(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel info = new NotificationChannel(CH_INFO, "Дни рождения и уведомления", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(info);
        NotificationChannel fb = new NotificationChannel(CH_FALLBACK, "Будильник (резерв)", NotificationManager.IMPORTANCE_HIGH);
        AudioAttributes aa = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        fb.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), aa);
        fb.enableVibration(true);
        nm.createNotificationChannel(fb);
    }

    static void notifyFallback(Context ctx, String label) {
        try {
            ensureChannels(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            Intent oi = new Intent(ctx, MainActivity.class);
            oi.putExtra("tab", "al");
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, 102, oi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(ctx, CH_FALLBACK)
                    .setSmallIcon(R.drawable.ic_stat_alarm)
                    .setContentTitle("⏰ " + label)
                    .setContentText("Будильник")
                    .setCategory(Notification.CATEGORY_ALARM)
                    .setContentIntent(pi)
                    .setFullScreenIntent(pi, true)
                    .setAutoCancel(true)
                    .build();
            nm.notify(7002, n);
        } catch (Exception ignored) { }
    }

    static void notifyFallbackSilent(Context ctx, String label) {
        try {
            ensureChannels(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            Intent oi = new Intent(ctx, MainActivity.class);
            oi.putExtra("tab", "al");
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, 104, oi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification n = new Notification.Builder(ctx, CH_INFO)
                    .setSmallIcon(R.drawable.ic_stat_alarm)
                    .setContentTitle("Пропущенный будильник")
                    .setContentText(label)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(7003, n);
        } catch (Exception ignored) { }
    }

    static void fireBirthdays(Context c) {
        Context ctx = c.getApplicationContext();
        long now = System.currentTimeMillis();
        JSONArray list = arr(ctx, "bdall");
        JSONObject sent = obj(ctx, "bdsent");
        int[] ks = {7, 3, 2, 1, 0};
        long next = -1;
        boolean changed = false;
        int thisYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = 0; i < list.length(); i++) {
            JSONObject p = list.optJSONObject(i);
            if (p == null) continue;
            String[] q = p.optString("date", "").split("-");
            if (q.length < 3) continue;
            int by, bm, bd;
            try { by = Integer.parseInt(q[0]); bm = Integer.parseInt(q[1]); bd = Integer.parseInt(q[2]); } catch (Exception e) { continue; }
            String id = p.optString("id", "");
            String name = p.optString("name", "");
            for (int yy = thisYear; yy <= thisYear + 1; yy++) {
                Calendar n = Calendar.getInstance();
                n.clear();
                n.set(yy, bm - 1, bd, 0, 0, 0);
                for (int k : ks) {
                    Calendar t = (Calendar) n.clone();
                    t.add(Calendar.DAY_OF_MONTH, -k);
                    t.set(Calendar.HOUR_OF_DAY, 9);
                    t.set(Calendar.MINUTE, 0);
                    long tt = t.getTimeInMillis();
                    String key = id + "_" + yy + "_" + k;
                    if (tt <= now) {
                        if (tt > now - 21 * 3600 * 1000L && !sent.has(key)) {
                            putQ(sent, key, now);
                            changed = true;
                            postBirthday(ctx, key, name, k, n, yy - by);
                        }
                    } else if (next < 0 || tt < next) {
                        next = tt;
                    }
                }
            }
        }
        // чистим старые записи
        List<String> rm = new ArrayList<>();
        Iterator<String> it = sent.keys();
        while (it.hasNext()) {
            String key = it.next();
            try {
                int i2 = key.lastIndexOf('_');
                int i1 = key.lastIndexOf('_', i2 - 1);
                int y = Integer.parseInt(key.substring(i1 + 1, i2));
                if (y < thisYear - 1) rm.add(key);
            } catch (Exception e) { rm.add(key); }
        }
        for (String k : rm) { sent.remove(k); changed = true; }
        if (changed) sp(ctx).edit().putString("bdsent", sent.toString()).apply();

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent oi = new Intent(ctx, AlarmReceiver.class);
        oi.setAction(ACTION_BDAY);
        PendingIntent op = PendingIntent.getBroadcast(ctx, 200, oi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (next < 0) { am.cancel(op); return; }
        try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, op); } catch (Exception e) { am.set(AlarmManager.RTC_WAKEUP, next, op); }
    }

    private static void postBirthday(Context ctx, String key, String name, int k, Calendar n, int age) {
        try {
            ensureChannels(ctx);
            String when = k == 0 ? "сегодня" : k == 1 ? "завтра" : k == 7 ? "через неделю" : "через " + k + " дня";
            String date = two(n.get(Calendar.DAY_OF_MONTH)) + "." + two(n.get(Calendar.MONTH) + 1);
            String txt = k == 0 ? "сегодня день рождения!" : "день рождения " + when + " (" + date + ")";
            if (age > 0) txt += k == 0 ? " Исполняется " + age : ", исполнится " + age;
            Intent oi = new Intent(ctx, MainActivity.class);
            oi.putExtra("tab", "bd");
            oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(ctx, 103, oi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification nt = new Notification.Builder(ctx, CH_INFO)
                    .setSmallIcon(R.drawable.ic_stat_alarm)
                    .setContentTitle("🎂 " + name)
                    .setContentText(txt)
                    .setStyle(new Notification.BigTextStyle().bigText(txt))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(Math.abs(key.hashCode()), nt);
        } catch (Exception ignored) { }
    }

    /** Раз в сутки (после полуночи) обновляем виджеты. */
    static void scheduleTick(Context c) {
        Context ctx = c.getApplicationContext();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent oi = new Intent(ctx, AlarmReceiver.class);
        oi.setAction(ACTION_TICK);
        PendingIntent op = PendingIntent.getBroadcast(ctx, 300, oi, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar m = Calendar.getInstance();
        m.add(Calendar.DAY_OF_MONTH, 1);
        m.set(Calendar.HOUR_OF_DAY, 0);
        m.set(Calendar.MINUTE, 0);
        m.set(Calendar.SECOND, 20);
        m.set(Calendar.MILLISECOND, 0);
        try { am.setAndAllowWhileIdle(AlarmManager.RTC, m.getTimeInMillis(), op); } catch (Exception e) { am.set(AlarmManager.RTC, m.getTimeInMillis(), op); }
    }

    static void rescheduleAll(Context c) {
        Context ctx = c.getApplicationContext();
        try { scheduleNext(ctx); } catch (Exception ignored) { }
        try { fireBirthdays(ctx); } catch (Exception ignored) { }
        try { scheduleTick(ctx); } catch (Exception ignored) { }
        try { Widgets.updateAll(ctx); } catch (Exception ignored) { }
    }
}
