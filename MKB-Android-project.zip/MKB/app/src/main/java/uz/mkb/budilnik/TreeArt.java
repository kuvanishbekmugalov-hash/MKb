package uz.mkb.budilnik;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Рисует виджет «Шажара» в виде дерева: корень внизу, ветви вверх, листья — люди. */
final class TreeArt {
    private TreeArt() {}

    static final float NW = 1f, NH = 0.62f, PITCH = 1.18f, TRUNK = 0.45f, CG = 0.12f, SG = 0.35f;

    static final class P {
        String fn = "", birth = "", death = "";
        boolean male = true, alive = true, me = false;
    }

    static final class U {
        P p, sp;
        List<U> kids = new ArrayList<>();
        int depth;
        float cw, kw, w, cx;
    }

    static P person(JSONObject o, String me) {
        if (o == null) return null;
        P x = new P();
        x.fn = o.optString("fn", "");
        x.male = !"f".equals(o.optString("g", "m"));
        x.alive = o.optBoolean("alive", true);
        x.birth = o.optString("birth", "");
        x.death = o.optString("death", "");
        x.me = !me.isEmpty() && me.equals(o.optString("id", "#"));
        return x;
    }

    static U parse(JSONObject o, String me, int depth) {
        U u = new U();
        u.p = person(o.optJSONObject("p"), me);
        u.sp = person(o.optJSONObject("sp"), me);
        u.depth = depth;
        JSONArray k = o.optJSONArray("kids");
        if (k != null && depth < 40) {
            for (int i = 0; i < k.length(); i++) {
                JSONObject ko = k.optJSONObject(i);
                if (ko != null) u.kids.add(parse(ko, me, depth + 1));
            }
        }
        return u;
    }

    static int count(U u) {
        int n = (u.p != null ? 1 : 0) + (u.sp != null ? 1 : 0);
        for (U k : u.kids) n += count(k);
        return n;
    }

    static int deepest(U u) {
        int d = u.depth;
        for (U k : u.kids) d = Math.max(d, deepest(k));
        return d;
    }

    static float layout(U u, int maxD) {
        float cw = u.sp != null ? 2 * NW + CG : NW;
        float kw = 0;
        int n = 0;
        if (u.depth < maxD) {
            for (U k : u.kids) {
                kw += layout(k, maxD);
                n++;
            }
            if (n > 1) kw += SG * (n - 1);
        }
        u.cw = cw;
        u.kw = kw;
        u.w = Math.max(cw, kw);
        return u.w;
    }

    static void place(U u, float left, int maxD) {
        u.cx = left + u.w / 2f;
        if (u.depth < maxD) {
            float x = left + (u.w - u.kw) / 2f;
            for (U k : u.kids) {
                place(k, x, maxD);
                x += k.w + SG;
            }
        }
    }

    static Bitmap draw(Context c, int W, int H) {
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = Math.min(W, H) * 0.08f;
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, W, H), rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF2A7D46, 0xFF0D3A21, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, W, H, p);
        p.setShader(null);
        // крона
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x1CFFFFFF);
        cv.drawCircle(W * 0.50f, H * 0.40f, H * 0.30f, p);
        cv.drawCircle(W * 0.25f, H * 0.48f, H * 0.22f, p);
        cv.drawCircle(W * 0.75f, H * 0.48f, H * 0.22f, p);
        cv.drawCircle(W * 0.38f, H * 0.30f, H * 0.18f, p);
        cv.drawCircle(W * 0.64f, H * 0.28f, H * 0.18f, p);
        // земля
        float footH = H * 0.07f;
        p.setColor(0xFF1B4D2B);
        cv.drawOval(new RectF(W * 0.05f, H - footH * 1.5f, W * 0.95f, H + footH), p);

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextAlign(Paint.Align.CENTER);

        U root = null;
        String name = "Шажара";
        String me = "";
        try {
            JSONObject tr = new JSONObject(Scheduler.sp(c).getString("tree", "{}"));
            JSONObject ro = tr.optJSONObject("root");
            if (ro != null && ro.optJSONObject("p") != null) {
                me = tr.optString("me", "");
                if ("null".equals(me)) me = "";
                name = tr.optString("name", "Шажара");
                root = parse(ro, me, 0);
            }
        } catch (Exception ignored) { }

        if (root == null) {
            tp.setColor(0xFFFFFFFF);
            tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            String a = AlarmArt.fit(tp, "Шажара", W * 0.8f, H * 0.14f);
            cv.drawText(a, W / 2f, H * 0.45f, tp);
            tp.setTypeface(Typeface.DEFAULT);
            tp.setColor(0xFFD7F2DD);
            String b = AlarmArt.fit(tp, "Создайте дерево в приложении", W * 0.86f, H * 0.075f);
            cv.drawText(b, W / 2f, H * 0.56f, tp);
            return bm;
        }

        float pad = W * 0.04f;
        float headH = H * 0.13f;
        float availW = W - 2 * pad;
        float availH = H - headH - footH - pad;
        int md = deepest(root);
        float tw, s;
        float minPx = Math.max(46f, W * 0.07f);
        while (true) {
            tw = layout(root, md);
            float rows = md + 1;
            float totalH = (rows - 1) * PITCH + NH + TRUNK;
            s = Math.min(availW / tw, availH / totalH);
            s = Math.min(s, Math.min(W, H) * 0.30f);
            if (s >= minPx || md == 0) break;
            md--;
        }
        place(root, 0, md);

        float nodeW = s * NW, nodeH = s * NH;
        float offX = pad + (availW - tw * s) / 2f;
        float rootBottom = H - footH - TRUNK * s;
        float rootTop = rootBottom - nodeH;
        float pitchPx = PITCH * s;

        // ствол
        Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
        bp.setStyle(Paint.Style.STROKE);
        bp.setStrokeCap(Paint.Cap.ROUND);
        bp.setStrokeJoin(Paint.Join.ROUND);
        bp.setColor(0xFF9A6A3A);
        float rcx = offX + root.cx * s;
        bp.setStrokeWidth(Math.max(5f, nodeW * 0.30f));
        cv.drawLine(rcx, rootBottom - nodeH * 0.2f, rcx, H - footH * 0.6f, bp);
        // ветви
        bp.setStrokeWidth(Math.max(3f, nodeW * 0.07f));
        branches(cv, bp, root, offX, s, rootTop, pitchPx, nodeH, md);
        // листья-карточки
        nodes(cv, p, tp, root, offX, s, rootTop, pitchPx, nodeW, nodeH, md, minPx);

        // заголовок
        tp.setTextAlign(Paint.Align.LEFT);
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tp.setColor(0xFFFFFFFF);
        String head = name + " · " + count(root) + " чел.";
        String hs = AlarmArt.fit(tp, head, W - 2 * pad, headH * 0.46f);
        cv.drawText(hs, pad, headH * 0.70f, tp);
        return bm;
    }

    static void branches(Canvas cv, Paint bp, U u, float offX, float s, float rootTop, float pitchPx, float nodeH, int md) {
        if (u.depth >= md) return;
        float px = offX + u.cx * s;
        float py = rootTop - u.depth * pitchPx;
        for (U k : u.kids) {
            float kx = offX + k.cx * s;
            float ky = rootTop - k.depth * pitchPx + nodeH;
            float mid = (py + ky) / 2f;
            Path path = new Path();
            path.moveTo(px, py);
            path.cubicTo(px, mid, kx, mid, kx, ky);
            cv.drawPath(path, bp);
            branches(cv, bp, k, offX, s, rootTop, pitchPx, nodeH, md);
        }
    }

    static void nodes(Canvas cv, Paint p, Paint tp, U u, float offX, float s, float rootTop, float pitchPx,
                      float nodeW, float nodeH, int md, float minPx) {
        float top = rootTop - u.depth * pitchPx;
        float cx = offX + u.cx * s;
        if (u.sp != null) {
            float gap = CG * s;
            card(cv, p, tp, u.p, cx - gap / 2f - nodeW, top, nodeW, nodeH, minPx);
            card(cv, p, tp, u.sp, cx + gap / 2f, top, nodeW, nodeH, minPx);
        } else {
            card(cv, p, tp, u.p, cx - nodeW / 2f, top, nodeW, nodeH, minPx);
        }
        if (u.depth < md) {
            for (U k : u.kids) nodes(cv, p, tp, k, offX, s, rootTop, pitchPx, nodeW, nodeH, md, minPx);
        }
    }

    static void card(Canvas cv, Paint p, Paint tp, P x, float l, float t, float w, float h, float minPx) {
        if (x == null) return;
        int fill = !x.alive ? 0xFFE6E6E6 : x.male ? 0xFFDCEBFF : 0xFFFFE3EE;
        int stroke = !x.alive ? 0xFF8A8A8A : x.male ? 0xFF4A7BD8 : 0xFFD8548C;
        float rx = h * 0.30f;
        RectF rc = new RectF(l, t, l + w, t + h);
        p.setStyle(Paint.Style.FILL);
        p.setColor(fill);
        cv.drawRoundRect(rc, rx, rx, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(x.me ? Math.max(3f, w * 0.06f) : Math.max(1.5f, w * 0.025f));
        p.setColor(x.me ? 0xFFF5B301 : stroke);
        cv.drawRoundRect(rc, rx, rx, p);
        p.setStyle(Paint.Style.FILL);

        String year = "";
        if (x.alive) {
            if (x.birth.length() >= 4) year = x.birth.substring(0, 4);
        } else {
            year = "† " + (x.death.length() >= 4 ? x.death.substring(0, 4) : "");
        }
        boolean showYear = w >= minPx * 0.9f && !year.isEmpty();
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tp.setColor(0xFF14213D);
        String nm = AlarmArt.fit(tp, x.fn, w * 0.88f, h * 0.34f);
        cv.drawText(nm, l + w / 2f, t + (showYear ? h * 0.52f : h * 0.63f), tp);
        if (showYear) {
            tp.setTypeface(Typeface.DEFAULT);
            tp.setColor(0xFF4A5568);
            String y2 = AlarmArt.fit(tp, year, w * 0.88f, h * 0.24f);
            cv.drawText(y2, l + w / 2f, t + h * 0.84f, tp);
        }
    }
}
