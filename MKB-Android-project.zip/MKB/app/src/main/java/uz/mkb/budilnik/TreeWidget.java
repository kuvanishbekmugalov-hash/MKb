package uz.mkb.budilnik;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.RemoteViews;

public class TreeWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) { update(c, m, ids); }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) {
        update(c, m, new int[]{id});
    }

    static void update(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) {
            try {
                int[] s = Widgets.sizePx(c, m, id, 280, 220);
                Bitmap b = TreeArt.draw(c, s[0], s[1]);
                RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_image);
                rv.setImageViewBitmap(R.id.img, b);
                rv.setOnClickPendingIntent(R.id.root, Widgets.openTab(c, "tr", 3));
                m.updateAppWidget(id, rv);
            } catch (Exception ignored) { }
        }
    }
}
