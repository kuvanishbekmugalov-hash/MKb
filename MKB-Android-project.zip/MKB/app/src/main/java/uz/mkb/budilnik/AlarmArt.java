package uz.mkb.budilnik;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.Calendar;

/** Рисует виджет будильника: будильник со стрелками на время ближайшего сигнала. */
final class AlarmArt {
    private AlarmArt() {}

    static Bitmap draw(Context c, int W, int H) {
        Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = Math.min(W, H) * 0.13f;
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF006AFB, 0xFF01247A, Shader.TileMode.CLAMP));
        cv.drawRoundRect(new RectF(0, 0, W, H), rad, rad, p);
        p.setShader(null);

        long now = System.currentTimeMillis();
        Scheduler.Next n = Scheduler.nextAlarm(c, now);
        int hh = 10, mm = 10;
        String timeStr = "--:--";
        String label;
        String eta;
        if (n != null) {
            Calendar tc = Calendar.getInstance();
            tc.setTimeInMillis(n.t);
            hh = tc.get(Calendar.HOUR_OF_DAY);
            mm = tc.get(Calendar.MINUTE);
            timeStr = Scheduler.two(hh) + ":" + Scheduler.two(mm);
            label = n.label.isEmpty() ? "Будильник" : n.label;
            eta = eta(n.t - now);
        } else {
            label = "Нет будильников";
            eta = "Нажмите, чтобы добавить";
        }

        boolean wide = W > H * 1.3f;
        float r, cx, cy, tx, maxW, sizeTime, baseTime, baseLabel, baseEta;
        if (wide) {
            r = H * 0.27f;
            cx = W * 0.25f;
            cy = H * 0.54f;
            tx = W * 0.70f;
            maxW = W * 0.50f;
            sizeTime = Math.min(H * 0.30f, W * 0.16f);
            baseTime = H * 0.50f;
            baseLabel = baseTime + sizeTime * 0.50f;
            baseEta = baseLabel + sizeTime * 0.42f;
        } else {
            r = Math.min(W * 0.26f, H * 0.24f);
            cx = W / 2f;
            cy = H * 0.07f + r * 1.4f;
            tx = W / 2f;
            maxW = W * 0.88f;
            sizeTime = Math.min(H * 0.13f, W * 0.20f);
            baseTime = cy + r * 1.2f + sizeTime * 1.05f;
            baseLabel = baseTime + sizeTime * 0.50f;
            baseEta = baseLabel + sizeTime * 0.42f;
        }
        drawClock(cv, p, cx, cy, r, hh, mm);

        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tp.setColor(0xFFFFFFFF);
        String t1 = fit(tp, timeStr, maxW, sizeTime);
        cv.drawText(t1, tx, baseTime, tp);
        tp.setTypeface(Typeface.DEFAULT);
        tp.setColor(0xFFCFE0FF);
        String t2 = fit(tp, label, maxW, sizeTime * 0.42f);
        cv.drawText(t2, tx, baseLabel, tp);
        tp.setColor(0xFFFFE082);
        String t3 = fit(tp, eta, maxW, sizeTime * 0.38f);
        cv.drawText(t3, tx, baseEta, tp);
        return bm;
    }

    static String fit(Paint p, String s, float maxW, float size) {
        p.setTextSize(size);
        while (p.measureText(s) > maxW && size > 9) {
            size -= 1;
            p.setTextSize(size);
        }
        String t = s;
        while (p.measureText(t) > maxW && t.length() > 3) t = t.substring(0, t.length() - 2) + "…";
        return t;
    }

    static String eta(long ms) {
        long mn = Math.round(ms / 60000.0);
        if (mn < 1) return "менее минуты";
        long d = mn / 1440;
        long h = (mn % 1440) / 60;
        long m = mn % 60;
        StringBuilder sb = new StringBuilder("через ");
        if (d > 0) sb.append(d).append(" д ");
        if (h > 0) sb.append(h).append(" ч ");
        if (m > 0 || (d == 0 && h == 0)) sb.append(m).append(" мин");
        return sb.toString().trim();
    }

    static void drawClock(Canvas cv, Paint p, float cx, float cy, float r, int hh, int mm) {
        // волны звона
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0xFF33E0FF);
        p.setStrokeWidth(r * 0.09f);
        float R = r * 1.3f;
        float oy = cy - r * 0.35f;
        RectF ov = new RectF(cx - R, oy - R, cx + R, oy + R);
        cv.drawArc(ov, 198, 34, false, p);
        cv.drawArc(ov, 308, 34, false, p);
        // ножки
        p.setColor(0xFFE8F0FF);
        p.setStrokeWidth(r * 0.13f);
        cv.drawLine(cx - r * 0.55f, cy + r * 0.88f, cx - r * 0.75f, cy + r * 1.2f, p);
        cv.drawLine(cx + r * 0.55f, cy + r * 0.88f, cx + r * 0.75f, cy + r * 1.2f, p);
        // колокольчики и кнопка
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE8F0FF);
        cv.drawCircle(cx - r * 0.74f, cy - r * 0.82f, r * 0.36f, p);
        cv.drawCircle(cx + r * 0.74f, cy - r * 0.82f, r * 0.36f, p);
        cv.drawRoundRect(new RectF(cx - r * 0.14f, cy - r * 1.22f, cx + r * 0.14f, cy - r * 0.98f), r * 0.08f, r * 0.08f, p);
        // корпус и циферблат
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(cx, cy, r, p);
        p.setColor(0xFF0B2B6E);
        cv.drawCircle(cx, cy, r * 0.8f, p);
        // деления
        p.setStyle(Paint.Style.STROKE);
        for (int i = 0; i < 12; i++) {
            boolean q = i % 3 == 0;
            double a = Math.toRadians(i * 30 - 90);
            float in = r * (q ? 0.57f : 0.63f);
            float out = r * 0.72f;
            p.setColor(q ? 0xFF33E0FF : 0xFF7FA6E8);
            p.setStrokeWidth(r * (q ? 0.07f : 0.045f));
            cv.drawLine(cx + (float) Math.cos(a) * in, cy + (float) Math.sin(a) * in,
                    cx + (float) Math.cos(a) * out, cy + (float) Math.sin(a) * out, p);
        }
        // стрелки на время сигнала
        double ha = Math.toRadians((hh % 12 + mm / 60f) * 30 - 90);
        double ma = Math.toRadians(mm * 6 - 90);
        p.setStrokeWidth(r * 0.085f);
        p.setColor(0xFFFFFFFF);
        cv.drawLine(cx, cy, cx + (float) Math.cos(ha) * r * 0.40f, cy + (float) Math.sin(ha) * r * 0.40f, p);
        p.setColor(0xFFB8F1FF);
        p.setStrokeWidth(r * 0.065f);
        cv.drawLine(cx, cy, cx + (float) Math.cos(ma) * r * 0.60f, cy + (float) Math.sin(ma) * r * 0.60f, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        cv.drawCircle(cx, cy, r * 0.075f, p);
    }
}
