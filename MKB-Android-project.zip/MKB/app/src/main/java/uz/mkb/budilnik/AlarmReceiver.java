package uz.mkb.budilnik;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (a == null) return;
        try {
            if (Scheduler.ACTION_ALARM.equals(a)) {
                Scheduler.fire(ctx);
            } else if (Scheduler.ACTION_BDAY.equals(a)) {
                Scheduler.fireBirthdays(ctx);
                Widgets.updateAll(ctx);
            } else if (Scheduler.ACTION_TICK.equals(a)) {
                Widgets.updateAll(ctx);
                Scheduler.fireBirthdays(ctx);
                Scheduler.scheduleTick(ctx);
            }
        } catch (Exception ignored) { }
    }
}
