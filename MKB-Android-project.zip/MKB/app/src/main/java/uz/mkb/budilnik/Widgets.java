package uz.mkb.budilnik;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

final class Widgets {
    private Widgets() {}

    static final String[] GEN = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля",
            "августа", "сентября", "октября", "ноября", "декабря"};

    static void updateAll(Context c) {
        try {
            Context ctx = c.getApplicationContext();
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            int[] a = m.getAppWidgetIds(new ComponentName(ctx, AlarmWidget.class));
            if (a != null && a.length > 0) AlarmWidget.update(ctx, m, a);
            int[] b = m.getAppWidgetIds(new ComponentName(ctx, BirthdayWidget.class));
            if (b != null && b.length > 0) BirthdayWidget.update(ctx, m, b);
            int[] t = m.getAppWidgetIds(new ComponentName(ctx, TreeWidget.class));
            if (t != null && t.length > 0) TreeWidget.update(ctx, m, t);
        } catch (Exception ignored) { }
    }

    /** Размер битмапа под виджет в пикселях. */
    static int[] sizePx(Context c, AppWidgetManager m, int id, int defWdp, int defHdp) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        int w = 0, h = 0;
        try {
            Bundle o = m.getAppWidgetOptions(id);
            if (o != null) {
                w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
                h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
            }
        } catch (Exception ignored) { }
        if (w <= 0) w = defWdp;
        if (h <= 0) h = defHdp;
        int wp = Math.round(w * dm.density);
        int hp = Math.round(h * dm.density);
        wp = Math.max(160, Math.min(wp, 900));
        hp = Math.max(160, Math.min(hp, 900));
        long px = (long) wp * hp;
        if (px > 650000L) {
            double k = Math.sqrt(650000.0 / px);
            wp = (int) (wp * k);
            hp = (int) (hp * k);
        }
        return new int[]{wp, hp};
    }

    static PendingIntent openTab(Context c, String tab, int req) {
        Intent i = new Intent(c, MainActivity.class);
        i.putExtra("tab", tab);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 500 + req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    // ---------- ближайшие дни рождения ----------
    static final class Bd {
        String name;
        int days;
        int age;
        int month;
        int day;
    }

    static List<Bd> upcoming(Context c) {
        List<Bd> out = new ArrayList<>();
        JSONArray list = Scheduler.arr(c, "bdall");
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        for (int i = 0; i < list.length(); i++) {
            JSONObject p = list.optJSONObject(i);
            if (p == null) continue;
            String[] q = p.optString("date", "").split("-");
            if (q.length < 3) continue;
            try {
                int by = Integer.parseInt(q[0]);
                int bm = Integer.parseInt(q[1]);
                int bd = Integer.parseInt(q[2]);
                Calendar n = Calendar.getInstance();
                n.clear();
                n.set(today.get(Calendar.YEAR), bm - 1, bd, 0, 0, 0);
                if (n.before(today)) {
                    n.clear();
                    n.set(today.get(Calendar.YEAR) + 1, bm - 1, bd, 0, 0, 0);
                }
                Bd b = new Bd();
                b.name = p.optString("name", "");
                b.days = (int) Math.round((n.getTimeInMillis() - today.getTimeInMillis()) / 86400000.0);
                b.age = n.get(Calendar.YEAR) - by;
                b.month = bm;
                b.day = bd;
                out.add(b);
            } catch (Exception ignored) { }
        }
        Collections.sort(out, new Comparator<Bd>() {
            @Override
            public int compare(Bd a, Bd b) { return a.days - b.days; }
        });
        return out;
    }

    static String whenText(int days) {
        if (days <= 0) return "Сегодня! 🎉";
        if (days == 1) return "Завтра";
        return "через " + days + " дн.";
    }
}
