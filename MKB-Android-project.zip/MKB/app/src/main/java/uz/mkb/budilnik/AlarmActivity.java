package uz.mkb.budilnik;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Полноэкранный экран будильника (поверх экрана блокировки). */
public class AlarmActivity extends Activity {
    private static AlarmActivity cur;
    private Button stopBtn;

    static void finishCurrent() {
        final AlarmActivity a = cur;
        if (a != null) {
            a.runOnUiThread(new Runnable() {
                @Override
                public void run() { a.finish(); }
            });
        }
    }

    private int px(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int color, int textColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        b.setTextColor(textColor);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(px(28));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(px(300), px(58));
        lp.topMargin = px(14);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
        cur = this;
        if (!AlarmService.ringing) {
            finish();
            return;
        }
        build();
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(px(24), px(24), px(24), px(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF0F2A6B, 0xFF0A6C74}));

        root.addView(text("⏰", 72, false));
        root.addView(text(AlarmService.curTime, 64, true));
        TextView lab = text(AlarmService.curLabel, 22, false);
        lab.setTextColor(0xFFD6F5F5);
        lab.setPadding(0, px(8), 0, px(8));
        root.addView(lab);

        stopBtn = button("Выключить", 0xFFFFFFFF, 0xFF14213D);
        Button snz = button("Отложить на " + AlarmService.curSnooze + " мин", 0x33FFFFFF, Color.WHITE);

        if (AlarmService.curMath) {
            final int answer = AlarmService.mathX + AlarmService.mathY;
            TextView q = text(AlarmService.mathX + " + " + AlarmService.mathY + " = ?", 30, true);
            q.setPadding(0, px(18), 0, px(6));
            root.addView(q);
            EditText et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER);
            et.setTextColor(Color.WHITE);
            et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
            et.setGravity(Gravity.CENTER);
            et.setLayoutParams(new LinearLayout.LayoutParams(px(180), LinearLayout.LayoutParams.WRAP_CONTENT));
            et.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) { }

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) { }

                @Override
                public void afterTextChanged(Editable e) {
                    boolean ok = false;
                    try { ok = Integer.parseInt(e.toString().trim()) == answer; } catch (Exception ignored) { }
                    stopBtn.setEnabled(ok);
                    stopBtn.setAlpha(ok ? 1f : 0.45f);
                }
            });
            root.addView(et);
            stopBtn.setEnabled(false);
            stopBtn.setAlpha(0.45f);
        }

        root.addView(stopBtn);
        root.addView(snz);

        stopBtn.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) { send(AlarmService.ACTION_STOP); }
        });
        snz.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) { send(AlarmService.ACTION_SNOOZE); }
        });
        setContentView(root);
    }

    private void send(String action) {
        Intent i = new Intent(this, AlarmService.class);
        i.setAction(action);
        try { startService(i); } catch (Exception e) { startForegroundService(i); }
        finish();
    }

    @Override
    public void onBackPressed() {
        // во время звонка выйти кнопкой «назад» нельзя
    }

    @Override
    protected void onDestroy() {
        if (cur == this) cur = null;
        super.onDestroy();
    }
}
