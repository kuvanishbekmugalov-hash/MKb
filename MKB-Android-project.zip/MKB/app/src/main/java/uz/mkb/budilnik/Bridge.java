package uz.mkb.budilnik;

import android.Manifest;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.PowerManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;

/** Мост JS → Android. В JS доступен как window.Android. */
public class Bridge {
    private final MainActivity act;
    private final Context ctx;
    private static MediaPlayer preview;

    Bridge(MainActivity a) {
        act = a;
        ctx = a.getApplicationContext();
    }

    @JavascriptInterface
    public boolean isApp() { return true; }

    @JavascriptInterface
    public void syncData(String key, String json) {
        try {
            if (key == null || json == null) return;
            if ("alarms".equals(key)) {
                Scheduler.onAlarmsSynced(ctx, json);
            } else if ("bdall".equals(key)) {
                Scheduler.onBirthdaysSynced(ctx, json);
            } else if ("tree".equals(key)) {
                Scheduler.sp(ctx).edit().putString("tree", json).apply();
                Widgets.updateAll(ctx);
            }
        } catch (Exception ignored) { }
    }

    /** Сохраняет звук будильника в файл. Возвращает true, если получилось. */
    @JavascriptInterface
    public boolean saveSound(String key, String dataUrl) {
        try {
            int c = dataUrl.indexOf(',');
            String b64 = c >= 0 ? dataUrl.substring(c + 1) : dataUrl;
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            if (bytes.length == 0) return false;
            FileOutputStream o = new FileOutputStream(Scheduler.soundFile(ctx, key));
            try { o.write(bytes); } finally { o.close(); }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void playSound(String key) {
        stopSound();
        try {
            File f = Scheduler.soundFile(ctx, key);
            if (!f.exists()) return;
            MediaPlayer m = new MediaPlayer();
            m.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            m.setDataSource(f.getAbsolutePath());
            m.prepare();
            m.start();
            preview = m;
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void stopSound() {
        try {
            if (preview != null) {
                try { preview.stop(); } catch (Exception ignored) { }
                preview.release();
            }
        } catch (Exception ignored) { }
        preview = null;
    }

    @JavascriptInterface
    public String status() {
        JSONObject o = new JSONObject();
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            boolean notif = nm.areNotificationsEnabled();
            if (Build.VERSION.SDK_INT >= 33) {
                notif = notif && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            }
            boolean fsi = Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent();
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            boolean bat = pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
            o.put("notif", notif);
            o.put("fsi", fsi);
            o.put("battery", bat);
            o.put("maker", Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase());
            o.put("sdk", Build.VERSION.SDK_INT);
        } catch (Exception ignored) { }
        return o.toString();
    }

    @JavascriptInterface
    public void setup() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() { act.runSetup(); }
        });
    }

    @JavascriptInterface
    public void openSettings() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() { act.openAppSettings(); }
        });
    }

    @JavascriptInterface
    public void testAlarm() { Scheduler.ringTest(ctx); }

    @JavascriptInterface
    public void share(final String text) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    act.startActivity(Intent.createChooser(i, "Поделиться"));
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void copy(final String text) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("shajara", text));
                } catch (Exception ignored) { }
            }
        });
    }
}
