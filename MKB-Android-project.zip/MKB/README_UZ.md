# MKB (AqlliBudilnik) — Android loyihasi

Time.html ilovangiz asosida tayyorlangan to'liq Android loyiha: **fon rejimida ishlaydigan budilnik**, 3 ta vidjet (Budilnik, Eng yaqin tug'ilgan kun, Shajara daraxti) va sizning MKB ikonkangiz.

## 1. APK yig'ish

### A) Telefondan, kompyutersiz (GitHub Actions)
1. github.com'da bepul akkaunt oching → **New repository** (Private bo'lsa ham bo'ladi).
2. Shu ZIP ichidagi barcha fayl va papkalarni repozitoriyga yuklang (**Add file → Upload files**).
3. `.github` papkasi yashirin bo'lgani uchun telefondan yuklanmasa: **Add file → Create new file**, nomiga `.github/workflows/build-apk.yml` deb yozing va shu ZIP ichidagi `.github/workflows/build-apk.yml` mazmunini nusxalab qo'ying.
4. **Actions** → **Build MKB APK** → **Run workflow**. 5–8 daqiqa kuting.
5. Tugagach ish ichidagi **Artifacts → MKB-debug-apk** ni yuklab oling, ichidan `app-debug.apk` ni o'rnating (Android "noma'lum manba" ruxsatini so'raydi).

### B) Kompyuterda
Android Studio **Koala (2024.1.1) yoki yangiroq** → **Open** → shu papkani tanlang → Sync tugagach **Build → Build APK(s)**.
Fayl: `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Birinchi ishga tushirish (muhim!)
1. Ilovani oching → **Будильник** bo'limi → **Настроить** tugmasini bosing va chiqqan ruxsatlarni bering:
   bildirishnomalar, ekran qulfi ustida ko'rsatish, batareya cheklovisiz.
2. **🔔 Проверить** tugmasi budilnikni darhol sinab ko'radi.
3. Xiaomi / Redmi / Poco / Huawei / Honor / Oppo / Realme / Vivo / Samsung: ilova sozlamalarida **Avtozapusk**ni yoqing va batareya cheklovini olib tashlang, aks holda tizim budilnikni "uxlatib" qo'yishi mumkin.

## 3. Vidjetlar
Bosh ekranni uzoq bosing → **Vidjetlar** → **MKB**:
- **MKB · Будильник** — budilnik shaklida, strelkalar ketma-ket signal vaqtini ko'rsatadi.
- **MKB · День рождения** — eng yaqin tug'ilgan kun (+ keyingi ikkitasi).
- **MKB · Шажара** — daraxt ko'rinishida: ildiz (ota-ona) pastda, avlodlar tepaga o'sadi. Ilovada tanlangan shajara ko'rsatiladi.
Vidjetni bossangiz, ilovaning tegishli bo'limi ochiladi. Vidjetlar ilovada ma'lumot o'zgarganda va har tunda yangilanadi.

## 4. Loyiha tuzilmasi
- `app/src/main/assets/index.html` — sizning ilovangiz (tuzatilgan).
- `Scheduler.java` — signal va tug'ilgan kun eslatmalari rejasi (`setAlarmClock`, Doze'da ham ishlaydi).
- `AlarmService/AlarmActivity.java` — ovoz, tebranish, ekran qulfi ustidagi ekran, misol yechish, kechiktirish.
- `AlarmWidget/BirthdayWidget/TreeWidget` + `AlarmArt/TreeArt` — vidjetlar.
- `Bridge.java` — JS ↔ Android ko'prigi.

## 5. Release (Play Market) uchun
`assembleDebug` o'rniga o'z kalitingiz bilan `assembleRelease` yoki Android Studio'da **Generate Signed Bundle** ishlating.
